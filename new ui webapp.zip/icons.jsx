/* global React */
const { useState, useEffect, useRef, useMemo } = React;

// ============================================================================
// ICONS — single source of truth for all lucide-style line icons
// Stroke 1.6, currentColor, 24×24 by default
// ============================================================================
const Ic = ({ d, size = 18, stroke = 1.6, fill = "none", style, children }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill}
    stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
    style={style}>
    {d ? <path d={d} /> : children}
  </svg>
);

const Icons = {
  Home: (p) => <Ic {...p}><path d="M3 11l9-8 9 8" /><path d="M5 10v10h14V10" /></Ic>,
  Grid: (p) => <Ic {...p}><rect x="3" y="3" width="7" height="7" rx="1.2"/><rect x="14" y="3" width="7" height="7" rx="1.2"/><rect x="3" y="14" width="7" height="7" rx="1.2"/><rect x="14" y="14" width="7" height="7" rx="1.2"/></Ic>,
  Cog: (p) => <Ic {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1A1.7 1.7 0 0 0 9 19.3a1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 4.7 15a1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 4.7 9a1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 9 4.7 1.7 1.7 0 0 0 10 3.2V3a2 2 0 1 1 4 0v.1A1.7 1.7 0 0 0 15 4.7a1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 19.3 9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></Ic>,
  Calendar: (p) => <Ic {...p}><rect x="3" y="4.5" width="18" height="17" rx="2"/><path d="M3 9h18M8 3v3M16 3v3"/></Ic>,
  Bell: (p) => <Ic {...p}><path d="M6 8a6 6 0 1 1 12 0c0 4.5 1.5 6 1.5 6h-15S6 12.5 6 8z"/><path d="M10 19a2 2 0 0 0 4 0"/></Ic>,
  Search: (p) => <Ic {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></Ic>,
  ChevronRight: (p) => <Ic {...p}><path d="m9 6 6 6-6 6"/></Ic>,
  ChevronLeft: (p) => <Ic {...p}><path d="m15 6-6 6 6 6"/></Ic>,
  ChevronDown: (p) => <Ic {...p}><path d="m6 9 6 6 6-6"/></Ic>,
  ArrowLeft: (p) => <Ic {...p}><path d="M19 12H5M12 19l-7-7 7-7"/></Ic>,
  ArrowRight: (p) => <Ic {...p}><path d="M5 12h14M12 5l7 7-7 7"/></Ic>,
  Plus: (p) => <Ic {...p}><path d="M12 5v14M5 12h14"/></Ic>,
  More: (p) => <Ic {...p}><circle cx="6" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="18" cy="12" r="1.4"/></Ic>,
  Filter: (p) => <Ic {...p}><path d="M3 5h18M6 12h12M10 19h4"/></Ic>,
  Menu: (p) => <Ic {...p}><path d="M3 6h18M3 12h18M3 18h18"/></Ic>,
  Phone: (p) => <Ic {...p}><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.7a2 2 0 0 1-.5 2.1L8 9.7a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.5 2.7.6a2 2 0 0 1 1.7 2.3Z"/></Ic>,
  Chat: (p) => <Ic {...p}><path d="M21 12a9 9 0 1 1-3.5-7.1L21 4l-1 3.4A9 9 0 0 1 21 12Z"/><path d="M8 11h.01M12 11h.01M16 11h.01"/></Ic>,
  Edit: (p) => <Ic {...p}><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></Ic>,
  MapPin: (p) => <Ic {...p}><path d="M20 10c0 7-8 12-8 12s-8-5-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></Ic>,
  Users: (p) => <Ic {...p}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9"/><path d="M16 3.1a4 4 0 0 1 0 7.8"/></Ic>,
  User: (p) => <Ic {...p}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></Ic>,
  Moon: (p) => <Ic {...p}><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/></Ic>,
  Cloud: (p) => <Ic {...p}><path d="M17.5 19a4.5 4.5 0 1 0-1.4-8.8 6 6 0 0 0-11.6 1.4A4 4 0 0 0 5 19h12.5Z"/></Ic>,
  Globe: (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></Ic>,
  Bed: (p) => <Ic {...p}><path d="M2 9v11M22 14v6M2 14h20M2 14V9a3 3 0 0 1 3-3h7v8"/><circle cx="7" cy="11" r="2"/></Ic>,
  Door: (p) => <Ic {...p}><path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16"/><path d="M3 21h18M15 12h.01"/></Ic>,
  Broom: (p) => <Ic {...p}><path d="M19 8 13 14M14 7l3 3M5 21l4-4M21 6l-3-3-8 8 3 3 8-8ZM10 14l-4 4 3 3 4-4"/></Ic>,
  Cart: (p) => <Ic {...p}><circle cx="9" cy="20" r="1.6"/><circle cx="18" cy="20" r="1.6"/><path d="M2 3h3l3 13h12l2-8H7"/></Ic>,
  Alert: (p) => <Ic {...p}><path d="M10.3 3.86a2 2 0 0 1 3.4 0l8 13.86A2 2 0 0 1 20 21H4a2 2 0 0 1-1.7-3.28Z"/><path d="M12 9v4M12 17h.01"/></Ic>,
  Flame: (p) => <Ic {...p}><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-3-3-3-3-6 0 0-6 4-6 9a6 6 0 0 0 12 0c0-3-3-6-3-6"/></Ic>,
  Cup: (p) => <Ic {...p}><path d="M3 9h14l-1 9a3 3 0 0 1-3 2.7H7a3 3 0 0 1-3-2.7L3 9Z"/><path d="M17 9a3 3 0 0 1 0 6h-1M8 4l1 3M12 4l1 3"/></Ic>,
  Leaf: (p) => <Ic {...p}><path d="M11 20A7 7 0 0 1 4 13c0-5 5-9 12-9 1 5-1 13-7 14-3 0-5-2-5-4 0-3 4-5 8-5"/></Ic>,
  Wrench: (p) => <Ic {...p}><path d="M14.7 6.3a4 4 0 0 0 5 5l-9.4 9.4a2 2 0 1 1-2.8-2.8l9.4-9.4a4 4 0 0 0-2.2-2.2Z"/></Ic>,
  Knife: (p) => <Ic {...p}><path d="M11 17 4 21l3-7 13-13 4 4Z"/><path d="m11 17-2-2"/></Ic>,
  Spa: (p) => <Ic {...p}><path d="M12 2c2 4 5 5 5 9a5 5 0 0 1-10 0c0-4 3-5 5-9Z"/><path d="M4 22c4-2 6-4 8-9 2 5 4 7 8 9"/></Ic>,
  Bike: (p) => <Ic {...p}><circle cx="5.5" cy="17.5" r="3.5"/><circle cx="18.5" cy="17.5" r="3.5"/><path d="M15 6h3l2 6M12 17.5 8 7l-2 3"/></Ic>,
  Clock: (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></Ic>,
  Check: (p) => <Ic {...p}><path d="m5 12 5 5L20 7"/></Ic>,
  CheckCircle: (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/></Ic>,
  XCircle: (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/></Ic>,
  Box: (p) => <Ic {...p}><path d="M21 16V8l-9-5-9 5v8l9 5 9-5Z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/></Ic>,
  Crown: (p) => <Ic {...p}><path d="m3 7 4 6 5-8 5 8 4-6v12H3z"/></Ic>,
  Diamond: (p) => <Ic {...p}><path d="m6 3 6 18 6-18-6 4-6-4Z"/><path d="M3 7h18"/></Ic>,
  Refresh: (p) => <Ic {...p}><path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5"/></Ic>,
  Sparkles: (p) => <Ic {...p}><path d="M12 3v5M12 16v5M3 12h5M16 12h5M5.6 5.6l3.5 3.5M14.9 14.9l3.5 3.5M18.4 5.6l-3.5 3.5M9.1 14.9l-3.5 3.5"/></Ic>,
  Plane: (p) => <Ic {...p}><path d="M21 16v-2L13 9V4a1.5 1.5 0 0 0-3 0v5L2 14v2l8-2v5l-2 1v2l3.5-1 3.5 1v-2l-2-1v-5Z"/></Ic>,
  CreditCard: (p) => <Ic {...p}><rect x="2.5" y="5" width="19" height="14" rx="2"/><path d="M2.5 10h19M6 15h3"/></Ic>,
  Receipt: (p) => <Ic {...p}><path d="M4 4v17l3-2 3 2 3-2 3 2 3-2V4Z"/><path d="M8 9h8M8 13h6"/></Ic>,
  Star: (p) => <Ic {...p}><path d="m12 3 2.9 6 6.5.6-5 4.4 1.6 6.4L12 17l-6 3.4 1.6-6.4-5-4.4 6.5-.6Z"/></Ic>,
  Info: (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="M12 16v-5M12 8h.01"/></Ic>,
  Clipboard: (p) => <Ic {...p}><rect x="6" y="4" width="12" height="18" rx="2"/><path d="M9 4V3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1"/><path d="M9 10h6M9 14h6"/></Ic>,
  Tag: (p) => <Ic {...p}><path d="M20 12 12 20l-9-9V3h8Z"/><circle cx="7.5" cy="7.5" r="1.4"/></Ic>,
  Trending: (p) => <Ic {...p}><path d="M3 17 9 11l4 4 8-8"/><path d="M14 7h7v7"/></Ic>,
  PieChart: (p) => <Ic {...p}><path d="M21 13A9 9 0 1 1 11 3v10z"/><path d="M21 11a9 9 0 0 0-8-8v8z"/></Ic>,
  BarChart: (p) => <Ic {...p}><path d="M3 21h18"/><rect x="5" y="11" width="3" height="8" rx="0.5"/><rect x="10.5" y="6" width="3" height="13" rx="0.5"/><rect x="16" y="14" width="3" height="5" rx="0.5"/></Ic>,
  Wallet: (p) => <Ic {...p}><path d="M21 8H5a2 2 0 0 0 0 4h16v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h13Z"/><path d="M17 13h.01"/></Ic>,
  Upload: (p) => <Ic {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 9l5-5 5 5M12 4v12"/></Ic>,
  Download: (p) => <Ic {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 11l5 5 5-5M12 4v12"/></Ic>,
  Hand: (p) => <Ic {...p}><path d="M7 11V5a2 2 0 1 1 4 0v6m0 0V3a2 2 0 1 1 4 0v8m0 0V5a2 2 0 1 1 4 0v8a8 8 0 0 1-8 8H8a4 4 0 0 1-4-4l-1-6c-.3-1.5 1.8-2.5 2.5-1l1.5 3"/></Ic>,
  Sun: (p) => <Ic {...p}><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/></Ic>,
  Music: (p) => <Ic {...p}><path d="M9 17V5l11-2v12"/><circle cx="6" cy="17" r="3"/><circle cx="17" cy="15" r="3"/></Ic>,
  Lock: (p) => <Ic {...p}><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 1 1 8 0v4"/></Ic>,
  Shield: (p) => <Ic {...p}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/></Ic>,
  Logout: (p) => <Ic {...p}><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5M15 12H3"/></Ic>,
  Headset: (p) => <Ic {...p}><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1v-6h3Z M3 19a2 2 0 0 0 2 2h1v-6H3Z"/></Ic>,
  ListCheck: (p) => <Ic {...p}><path d="M16 6h5M16 12h5M16 18h5"/><path d="m3 6 2 2 4-4M3 12l2 2 4-4M3 18l2 2 4-4"/></Ic>,
  DollarBadge: (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="M15 8h-4a2 2 0 0 0 0 4h2a2 2 0 0 1 0 4H9"/><path d="M12 7v1M12 16v1"/></Ic>,
  TrendUp: (p) => <Ic {...p}><path d="M3 17 9 11l4 4 8-8M14 7h7v7"/></Ic>,
};

window.Ic = Ic;
window.Icons = Icons;
